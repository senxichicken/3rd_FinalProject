import tkinter as tk

def function_A():
    # 執行相應的操作
    print("執行函式 A")
    # 更改按鈕的文字
    button.config(text="開始", command=function_B)

def function_B():
    # 執行相應的操作
    print("執行函式 B")
    # 更改按鈕的文字
    button.config(text="創建", command=function_A)

def button_click():
    # 獲取按鈕上的文字
    button_text = button.cget("text")

    # 根據按鈕上的文字執行相應的函式
    if button_text == "創建":
        function_A()
    elif button_text == "開始":
        function_B()

# 創建主視窗
root = tk.Tk()

# 創建按鈕並設定點擊事件
button = tk.Button(root, text="創建", command=button_click)
button.pack(pady=10)

# 啟動主迴圈
root.mainloop()