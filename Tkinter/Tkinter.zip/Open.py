import tkinter as tk
import Start

root = tk.Tk()
root.title('TRPG in to COC')
root.resizable(False, False)

window_width = root.winfo_screenwidth()    # 取得螢幕寬度
window_height = root.winfo_screenheight()  # 取得螢幕高度

width = 1280 
height = 800
left = int((window_width - width)/2)       # 計算左上 x 座標
top = int((window_height - height)/2) 
root.geometry(f'{width}x{height}+{left}+{top}')  # 定義視窗的尺寸和位置

wlclabel =tk.Label(root,
                   text = "歡迎來到TRPG之"+"\n"+"克蘇魯的呼喚",
                   font = ('Arial',35,'bold'),
                   fg = '#000000',
                   pady = 250,
                   )
wlclabel.pack()


btnStart = tk.Button(
                     root,
                     width = 8 , height = 1,
                     text = ("開始遊戲"),
                     font = ('Arial',15,'bold'),
                     fg = '#000000',
                     bg = '#808080',
                     command= lambda:Start.start(root,wlclabel,btnStart,btnAbout,btnExit)
                     )
btnAbout = tk.Button(root,
                     width = 8 , height = 1,
                     text = ("關於TRPG"),
                     font = ('Arial',15,'bold'),
                     fg = '#000000',
                     bg = '#808080')
btnExit = tk.Button(root,
                     width = 8 , height = 1,
                     text = ("離開遊戲"),
                     font = ('Arial',15,'bold'),
                     fg = '#000000',
                     bg = '#808080')



btnStart.pack()
btnAbout.pack()
btnExit.pack()

root.mainloop()