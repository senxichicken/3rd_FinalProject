import openai
import chractercard
with open('D:/Homework/specialsubject/project/secretkey.txt', 'r') as file:
    apikey = file.read().rstrip()

openai.api_key = apikey
playerdata = chractercard.player_data
if playerdata:
    Name = chractercard.player_data['姓名']
    Job = chractercard.player_data['職業']
    Sch = chractercard.player_data['學歷']
    Era = chractercard.player_data['背景年代']
    Sex = chractercard.player_data['性別']
    Age = chractercard.player_data['年齡']
    Born = chractercard.player_data['出生地']
    Live = chractercard.player_data['居住地']
    STR = chractercard.player_data['力量']
    CON = chractercard.player_data['體質']
    DEX = chractercard.player_data['敏捷']
    APP = chractercard.player_data['外貌']
    POW = chractercard.player_data['意志']
    INT = chractercard.player_data['智力']
    SIZ = chractercard.player_data['體型']
    EDU = chractercard.player_data['教育']
    LUK = chractercard.player_data['幸運']

def print_w(s):
    width = 70
    while len(s) > width:
        print(f's[:width:<{width}]')
        s = s[width:]

def chatGPT_api(list_msg, list_ans, message):
    
    system_role = '你是一個TRPG(桌上型角色扮演遊戲)中COC(克蘇魯的呼喚)模型的導演(KP)。請給予使用者一個約50個字的起始COC劇情'
    user_role = "我將以以下敘述的角色遊玩這次的角色扮演，姓名{Name}，職業{Job}，教育背景{Sch}，背景{Era}年代，性別{Sex}，年齡{Age}，出生地{Born}，居住地{Live}，力量{STR}、體質{CON}、敏捷{DEX}、外貌{APP}、意志力{POW}、智力{INT}、身材{SIZ}、學歷{EDU}、運氣{LUK}。請在每一次對話後詢問玩家的行動或請玩家投擲骰子，最後以骰子的值決定事件是否成功。若骰子的值小於玩家能力值則事件成功，反之則失敗。特別規則:骰子值為1、2、3時為大成功，獲得更多的獎勵，反之值為98、99、100則為大失敗，會有嚴重的懲罰。"
    send_msg = [ 
        {'role': 'system', 'content': system_role},
        {'role': 'user', 'content': user_role}
        ]

    # 讀取歷史訊息
    for i in range(len(list_msg)):
        _msg = {'role': 'user', 'content': list_msg[i]}
        send_msg.append(_msg)
        _ans = {'role': 'assistant', 'content': list_ans[i]}
        send_msg.append(_ans)

    # 玩家新回覆
    _msg = {'role': 'user', 'content': message}
    send_msg.append(_msg)

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=send_msg
    )
        
    # 直接返回 API 返回的助手回應
    return response["choices"][0]["message"]["content"]

def context():
    history_list_msg = []
    history_list_ans = []
    
    while True:
        message = input()
        if "偵查" in message:
            print("請投擲骰子確認事件是否成功!",end = "")
            message = input("")

            message = message * 100

        answer = chatGPT_api(history_list_msg, history_list_ans, message)
        history_list_msg.append(message)
        history_list_ans.append(answer)
        print(":回答")
        print(answer)
        print("\n")
        #print(history_list_ans)
        return answer

if __name__ == "__main__":
    context()