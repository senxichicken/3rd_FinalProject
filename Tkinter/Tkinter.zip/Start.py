import tkinter as tk
from PIL import Image, ImageTk
import chractercard
import threading
tk_img = None
chat = None
btnNext = None
img = Image.open('D:/Homework/specialsubject/project/Tkinter/picture/KP.png')


def start(root,wlclabel,btnStart,btnAbout,btnExit):
    global tk_img,chat,btnNext #必須宣告為全域變數，否則當label更改完畢後回到MainWindows時則tk_img會丟失。
    wlclabel.destroy()
    btnStart.destroy()
    btnAbout.destroy()
    btnExit.destroy()

    tk_img = ImageTk.PhotoImage(img)
    imglabel = tk.Label(root,
                        image=tk_img,
                        bg = '#000000',
                        padx = 10,
                        pady = 10,
                        )
    imglabel.pack()
    #print(imglabel)
    #print(img)

    btnNext = tk.Button(root,
                        text = ("下一頁"),
                        width= 5,height= 1 , #btn的大小是看字元數
                        font = ('Arial',15,'bold'),
                        fg = '#000000',
                        bg = '#808080',
                        command=  lambda:chat_Next(chat, btnNext)
                        )
    btnNext.pack(anchor= 'se')

    chat = tk.Label(root,
                    width= 1280,height= 150 ,
                    text = "接下來將由我帶您進入TPRG的世界",
                    font = ('Arial',20,'bold'),
                    fg = '#000000',
                    bg = '#808080',
                    pady = 30,
                    )
    chat.pack(anchor= 's')
    


def background_task():
    print(chractercard.player_data)
    
    timer = threading.Timer(2, background_task)
    timer.start()   
    if chractercard.player_data:
        #print("gg")
        timer.cancel()



#聊天室窗控制
def chat_Next(chat, btnNext):

    print("Button Text:", btnNext.cget("text"))

    if btnNext.cget("text") == "下一頁":
        btnNext.config(text="創建")
        chat.config(text="請建立一張屬於您自己的角色卡!")
        background_task()
        btnNext.config(command=lambda: chractercard.Card(chat, btnNext))


 